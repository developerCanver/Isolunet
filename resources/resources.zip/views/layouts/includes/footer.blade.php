<footer class="br-footer">
    <div class="footer-left">
      <div class="mg-b-2">Copyright &copy; 2020. ISOLUNET. Todos los derechos reservados.</div>
      <div>Desarrollado por CyG Colombia.</div>
    </div>
    <div class="footer-right d-flex align-items-center">
      <span class="tx-uppercase mg-l-10">Siguenos:</span>
      <a target="_blank" class="pd-x-5" href="#"><i class="fab fa-facebook tx-20"></i></a>
      <a target="_blank" class="pd-x-5" href="#"><i class="fab fa-twitter tx-20"></i></a>
    </div>
  </footer>