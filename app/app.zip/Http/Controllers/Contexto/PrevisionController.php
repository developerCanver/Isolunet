<?php

namespace App\Http\Controllers\Contexto;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PrevisionController extends Controller
{
    //
}
