<div class="row">
	<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
		<div class="form-group">
		    <label for="exampleInputEmail1">Partes Interesadas</label>
		    <input type="text" class="form-control" name="partes_interesadas" >
		</div>
	</div>
	<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
		<div class="form-group">
		    <label for="exampleInputEmail1">Impacto</label>
		    <select name="impacto" class="form-control">
		    	<option value="" selected>Seleccionar</option>
		    	<option value="1">1</option>
		    	<option value="2">2</option>
		    	<option value="3">3</option>
		    	<option value="4">4</option>
		    	<option value="5">5</option>
		    </select>
		</div>
	</div>
	<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
		<div class="form-group">
		    <label for="exampleInputEmail1">Influencia</label>
		    <select name="influencia" class="form-control">
		    	<option value="" selected>Seleccionar</option>
		    	<option value="1">1</option>
		    	<option value="2">2</option>
		    	<option value="3">3</option>
		    	<option value="4">4</option>
		    	<option value="5">5</option>
		    </select>
		</div>
	</div>
	<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12" style="margin-top: 3%;">
		<button type="submit" class="btn btn-success">Agregar</button>
	</div>
</div>