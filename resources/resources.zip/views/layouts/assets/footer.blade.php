<script src="{{ asset('dashboard/lib/jquery/jquery.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/jquery-ui/ui/widgets/datepicker.js') }} "></script>
<script src="{{ asset('dashboard/lib/bootstrap/js/bootstrap.bundle.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/perfect-scrollbar/perfect-scrollbar.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/moment/min/moment.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/peity/jquery.peity.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/rickshaw/vendor/d3.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/rickshaw/vendor/d3.layout.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/rickshaw/rickshaw.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/jquery.flot/jquery.flot.js') }} "></script>
<script src="{{ asset('dashboard/lib/jquery.flot/jquery.flot.resize.js') }} "></script>
<script src="{{ asset('dashboard/lib/flot-spline/js/jquery.flot.spline.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/jquery-sparkline/jquery.sparkline.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/echarts/echarts.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/select2/js/select2.full.min.js') }} "></script>

<script src="http://maps.google.com/maps/api/js?key=AIzaSyAq8o5-8Y5pudbJMJtDFzb8aHiWJufa5fg"></script>
<script src="{{ asset('dashboard/lib/gmaps/gmaps.min.js') }} "></script>

<script src="{{ asset('dashboard/js/bracket.js') }} "></script>
<script src="{{ asset('dashboard/js/map.shiftworker.js') }} "></script>
<script src="{{ asset('dashboard/js/ResizeSensor.js') }} "></script>
<script src="{{ asset('dashboard/js/dashboard.js') }} "></script>
<script src="{{ asset('dashboard/lib/datatables.net-responsive/js/dataTables.responsive.min.js') }} "></script>
<script src="{{ asset('dashboard/lib/datatables.net-responsive-dt/js/responsive.dataTables.min.js') }} "></script>

