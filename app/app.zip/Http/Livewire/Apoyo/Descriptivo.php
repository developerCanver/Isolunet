<?php

namespace App\Http\Livewire\Apoyo;

use Livewire\Component;

class Descriptivo extends Component
{
    public function render()
    {
        return view('livewire.apoyo.descriptivo');
    }
}
