<link href="{{ asset('dashboard/lib/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
<link href="{{ asset('dashboard/lib/ionicons/css/ionicons.min.css') }} " rel="stylesheet">
<link href="{{ asset('dashboard/lib/rickshaw/rickshaw.min.css') }}" rel="stylesheet">
<link href="{{ asset('dashboard/lib/select2/css/select2.min.css') }} " rel="stylesheet">

<!-- Bracket CSS -->
<link rel="stylesheet" href="{{ asset('dashboard/css/bracket.css') }}">
<link rel="stylesheet" type="text/css" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="{{ asset('dashboard/css/bracket.simple-white.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/main.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/lib/datatables.net-dt/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


