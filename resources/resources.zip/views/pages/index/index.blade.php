@extends('layouts.dashboard')

@section('content')

<div class="br-pagetitle">
	<i class="icon ion-ios-home-outline"></i>
	<div>
	  <h4>Dashboardq</h4>
	  {{-- <p class="mg-b-0">Administracion y Estadisticas personalizadas.</p> --}}
	</div>
</div><!-- d-flex -->


@endsection