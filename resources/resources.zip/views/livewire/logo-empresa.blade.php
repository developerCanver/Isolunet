<div>
 <div class="br-logo"><a href=""><span>[</span><i style="font-weight: 400;">{{$empresa->razon_social}}</i><span>]</span></a></div>
</div>
